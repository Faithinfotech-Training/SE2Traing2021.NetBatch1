﻿using System;
using System.Collections.Generic;
using CRM_Demo.Models;


#nullable disable

namespace Domain_Layer.Models
{
    public partial class ResourseEnquiry :BaseEntity
    {
        public int ResourceEnquiryId { get; set; }
        public string ResourceFullName { get; set; }
        public string ResourceEmail { get; set; }
        public string ResourcePhone { get; set; }
        public bool ResourceStatus { get; set; }
        public int ResourceEnId { get; set; }
        public DateTime ResourceErecordDate { get; set; }
        public DateTime ResourceEupdateDate { get; set; }

        public virtual Resource ResourceEn { get; set; }
    }
}
