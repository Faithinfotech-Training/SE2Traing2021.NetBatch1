import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CourseListComponent } from './course-list/course-list.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { CourseRecentComponent} from './course-recent/course-recent.component';

const routes: Routes = [
  { path: 'course', component: CourseListComponent },
  { path: 'course/:id', component: CourseDetailComponent },
  { path: 'post', component: CourseRecentComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [CourseRecentComponent]
})
export class CoursesRoutingModule { }
