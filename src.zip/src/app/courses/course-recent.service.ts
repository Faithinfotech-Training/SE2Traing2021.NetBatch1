import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CourseRecent } from './course-recent';

@Injectable({
  providedIn: 'root'
})
export class CourseRecentService {
  url = "http://localhost:44367/api/course";
  constructor(private http: HttpClient) { }
  getposts(): Observable<CourseRecent[]> {
    return this.http.get<CourseRecent[]>(this.url);
  }


  getPostById(PostId: string): Observable<CourseRecent> {
    return this.http.get<CourseRecent>(this.url + "/" + PostId)
  }

  
  createPost(post: CourseRecent, endpoint) {

    const formData: FormData = new FormData();

    formData.append('Title', post.Title);

    formData.append('Desc', post.Desc);

    formData.append('Price', post.Price.toString());

    return this.http.post(endpoint, formData);
  }



  updatePost(post: CourseRecent, endpoint) {

    
    const formData: FormData = new FormData();

    formData.append('Id', post.Id.toString());

    formData.append('Title', post.Title);

    formData.append('Desc', post.Desc);
    formData.append('Price', post.Price.toString());

    return this.http.post(endpoint, formData);
  }


  deletePostById(courseid: string): Observable<number> {
    return this.http.delete<number>(this.url + "/" + courseid);
  }
}



