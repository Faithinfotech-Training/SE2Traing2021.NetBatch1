import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { CourseRecentService } from '../course-recent.service';

@Component({
  selector: 'app-course-recent',
  templateUrl: './course-recent.component.html',
  styleUrls: ['./course-recent.component.css']
})
export class CourseRecentComponent implements OnInit {
  title = "Course Posts";
  allpost: any;
  showGrid = true;
  PostIdToUpdate = null;
  regForm = FormGroup;
  datasaved = false;
  message: string;
  formbuilder: any;
  endpoint: any;
  reset: any;
  value: any;
//   submitted: false;


  constructor(private courserecentservice: CourseRecentService, private Fb: FormBuilder ) { }

  ngOnInit(): void {
    this.setFormState();
    this.loadAllPost();
    this.showGrid = true;

  }


// onReset(){
//     this.submitted= false;
//     this.regForm.reset();
// }

//   onSubmit(Caption: any) {
//     let post = this.regForm.value;

//     if (this.PostIdToUpdate == null) {
//       post.Id = 0;

//       this.courserecentservice.createPost(post, this.endpoint).subscribe(
//         data => {

//           this.datasaved = true;

//           this.message = "Course Post Created";

//         //   this.regForm.reset();

//         }
//       );
//     } else {

//       post.Id = this.PostIdToUpdate;

//       this.courserecentservice.updatePost(post, this.endpoint).subscribe(

//         data => {

//           this.datasaved = true;

//           this.showGrid = true;

//           this.message = "Course Post Updated";

//         //   this.regForm.reset();

//           this.loadAllPost();
//         }
//       );
//     }
//   }


  Cancel() {

    this.datasaved = false;

    this.showGrid = true;

    this.message = "";

    // this.regForm.reset();

    this.loadAllPost();
  }



  deletePost(PostId: string) {

    this.datasaved = true;

    this.courserecentservice.deletePostById(PostId)

      .subscribe(() => {

        this.message = "Course Deleted Successfully";

        this.loadAllPost();

        this.PostIdToUpdate = null;

        // this.regForm.reset();

      })
  }



  editPost(PostId: string) {

    this.showGrid = false;

    this.datasaved = false;

    this.message = "";

    this.courserecentservice.getPostById(PostId).subscribe(post => {
      this.message = null;

      this.datasaved = false;

      this.PostIdToUpdate = post.Id;

    //   this.regForm.controls['Title'].setValue(post.Title);
    //   this.regForm.controls['Desc'].setValue(post.Desc);

    //   this.regForm.controls['Price'].setValue(post.Price);

    });
  }


  loadAllPost() {
    this.courserecentservice.getposts().subscribe((data) => {
      this.allpost = data
    })
  }

  addPost() {
    this.showGrid = false;
    this.datasaved = false;
    this.message = "";
    this.PostIdToUpdate = null;
  }


  setFormState(): void {

    this.regForm = this.formbuilder.group({

      Title: ['', [Validators.required]],

      Desc: ['', [Validators.required]],

      Price: ['', [Validators.required]],
    })


  }
}