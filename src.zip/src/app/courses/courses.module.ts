import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoursesRoutingModule } from './courses-routing.module';
import { CourseFeaturedComponent } from './course-featured/course-featured.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CourseRecentComponent } from './course-recent/course-recent.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { CourseCategoryComponent } from './course-category/course-category.component';
import { CourseRecentService} from './course-recent.service';



@NgModule({
  declarations: [CourseFeaturedComponent, CourseListComponent, CourseRecentComponent, CourseDetailComponent, CourseCategoryComponent],
  imports: [
    CommonModule,
    CoursesRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [CourseFeaturedComponent],
  providers: [CourseRecentService]

})
export class CoursesModule { }
