export class CourseRecent {
    Id: number;
    Title: string;
    Desc: string;
    Price: number;
    Availability: number;

}
