import { Resource } from './resource.model';

describe('Resource', () => {
  it('should create an instance', () => {
    expect(new Resource()).toBeTruthy();
  });
});
