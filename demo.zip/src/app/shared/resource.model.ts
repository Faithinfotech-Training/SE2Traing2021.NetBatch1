export class Resource {
    ResourceId:number=0;
    ResourceName:string='';
    ResourceDesc:string='';
    ResourcePrice:number=0;     
    Type:string='';
    Visibility:boolean=false;
}
