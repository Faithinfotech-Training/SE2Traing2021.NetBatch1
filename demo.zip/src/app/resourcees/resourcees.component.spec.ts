import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourceesComponent } from './resourcees.component';

describe('ResourceesComponent', () => {
  let component: ResourceesComponent;
  let fixture: ComponentFixture<ResourceesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResourceesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResourceesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
