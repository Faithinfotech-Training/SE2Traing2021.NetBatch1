import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ResourceesComponent } from './resourcees/resourcees.component';
import { ResourceComponent } from './resourcees/resource/resource.component';
import { ResourceListComponent } from './resourcees/resource-list/resource-list.component';
import { ResourceService } from './shared/resource.service';
import { InsightsComponent } from './insights/insights.component';
import { IcourseComponent } from './insights/icourse/icourse.component';
import { IresourceComponent } from './insights/iresource/iresource.component';

@NgModule({
  declarations: [
    AppComponent,
    ResourceesComponent,
    ResourceComponent,
    ResourceListComponent,
    InsightsComponent,
    IcourseComponent,
    IresourceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ResourceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
