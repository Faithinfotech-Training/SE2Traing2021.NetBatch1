import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IresourceComponent } from './iresource.component';

describe('IresourceComponent', () => {
  let component: IresourceComponent;
  let fixture: ComponentFixture<IresourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IresourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IresourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
