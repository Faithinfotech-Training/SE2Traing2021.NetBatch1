import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iresource',
  templateUrl: './iresource.component.html',
  styleUrls: ['./iresource.component.css']
})
export class IresourceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
