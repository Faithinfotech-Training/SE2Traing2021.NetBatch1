import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icourse',
  templateUrl: './icourse.component.html',
  styleUrls: ['./icourse.component.css']
})
export class IcourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
