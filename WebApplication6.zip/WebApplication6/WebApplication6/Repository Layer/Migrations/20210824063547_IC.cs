﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Repository_Layer.Migrations
{
    public partial class IC : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Course",
                columns: table => new
                {
                    CourseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Course_Name = table.Column<string>(type: "Varchar(100)", nullable: false),
                    Course_Desc = table.Column<string>(type: "Varchar(500)", nullable: false),
                    Course_Duration = table.Column<int>(type: "INT", nullable: false),
                    Course_Price = table.Column<decimal>(type: "DECIMAL", nullable: false),
                    Course_Availability = table.Column<bool>(type: "bit", nullable: false),
                    Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_courseId", x => x.CourseId);
                });

            migrationBuilder.CreateTable(
                name: "CourseEnquiry",
                columns: table => new
                {
                    courseEnquiryId = table.Column<int>(type: "INT", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    courseId = table.Column<int>(type: "int", nullable: true),
                    userName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    phoneNo = table.Column<string>(type: "nchar(10)", fixedLength: true, maxLength: 10, nullable: true),
                    DOB = table.Column<DateTime>(type: "date", nullable: false),
                    qualification = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    testScore = table.Column<int>(type: "int", nullable: true),
                    enquiryStatus = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_courseEnquiryId", x => x.courseEnquiryId);
                    table.ForeignKey(
                        name: "FK_CourseEnquiry_Courses",
                        column: x => x.courseId,
                        principalTable: "Course",
                        principalColumn: "CourseId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Trainee",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TraineeId = table.Column<int>(type: "int", nullable: false),
                    BatchId = table.Column<int>(type: "int", nullable: true),
                    CourseEnqId = table.Column<int>(type: "INT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Trainee", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Trainee_CourseEnquiry_CourseEnqId",
                        column: x => x.CourseEnqId,
                        principalTable: "CourseEnquiry",
                        principalColumn: "courseEnquiryId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CourseEnquiry_courseId",
                table: "CourseEnquiry",
                column: "courseId");

            migrationBuilder.CreateIndex(
                name: "IX_Trainee_CourseEnqId",
                table: "Trainee",
                column: "CourseEnqId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Trainee");

            migrationBuilder.DropTable(
                name: "CourseEnquiry");

            migrationBuilder.DropTable(
                name: "Course");
        }
    }
}
